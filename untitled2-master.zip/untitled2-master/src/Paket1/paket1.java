package Paket1;

public class paket1 {
}
